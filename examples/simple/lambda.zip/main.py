def lambda_handler(event, context):
    return {
        'statusCode': 200,
        'body': event['body'],
        'headers': {
            'X-Custom-Header': 'lambda-header',
        }
    }
